
int incr_mult(int a, int b){
    return ((++a) * (++b));
}