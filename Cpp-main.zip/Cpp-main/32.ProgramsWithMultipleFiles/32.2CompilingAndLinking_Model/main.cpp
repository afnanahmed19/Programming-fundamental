#include <iostream>
#include "utilities.h"

int main(){

    double result = add(10.5,20.8);
    std::cout << "result : " << result << std::endl;
    
    return 0;
}