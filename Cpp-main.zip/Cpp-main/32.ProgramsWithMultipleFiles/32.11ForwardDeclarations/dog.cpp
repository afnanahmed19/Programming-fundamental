#include "dog.h"

Dog::Dog(const std::string& name) : name(name)
{
}

Dog::~Dog()
{
}

