#include "point.h"

  //Initialize static member var
  size_t Point::m_point_count {0};