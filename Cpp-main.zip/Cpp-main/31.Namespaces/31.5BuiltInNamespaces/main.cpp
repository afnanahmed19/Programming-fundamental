#include <iostream>
#include <string>

int main(){
    
    std::cout << "Hello World" << std::endl;
    std::string message{"Hello World"};
    std::cout << message << std::endl;
    return 0;
}