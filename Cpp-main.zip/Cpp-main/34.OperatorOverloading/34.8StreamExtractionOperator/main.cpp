#include <iostream>
#include "point.h"

int main(){

    
    Point p2;

    std::cin >> p2;//

    std::cout << "p2 : " << p2 << std::endl;
   
    return 0;
}