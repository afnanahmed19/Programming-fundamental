#include <iostream>


/*
int max(int a, int b){
    return (a > b)? a : b;
}
*/


int max( int a,  int b);

int main(){

   
    return 0;
}

int max( int a,  int b){
    ++a;
    return (a > b)? a : b;
}